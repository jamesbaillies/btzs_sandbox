package com.example.btzs_sandbox

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
